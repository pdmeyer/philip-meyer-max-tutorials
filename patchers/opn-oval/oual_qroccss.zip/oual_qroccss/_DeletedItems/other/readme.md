How to use:
- Put your own audio files in media folder
- Open oual_qroccss.maxproj in Max